<?php

/*
 Generator @ Kodi dot AL Dev Tools
 Code For PHP 5/7
*/

define("YOUTUBE_API_KEY", "ENTER_API_KEY_HERE");

?>
