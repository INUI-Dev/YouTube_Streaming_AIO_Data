<?php

/*
 Generator @ Kodi dot AL Dev Tools
 Code For PHP 5/7
*/

//error_reporting(0);
header("Content-Type: application/rss+xml; charset=\"UTF-8\"");

include_once 'video_object.php';
include_once 'rss_generator.php';
include_once 'api_key.php';

function GET_JSON_API_DATA($url) {
    $data = file_get_contents($url);
    if ($data) {
        return json_decode($data);
    } else {
        return NULL;
    }
}

// https://www.googleapis.com/youtube/v3/channels?part=id&forUsername=TRC4Deejay&key=AIzaSyC5Ug8edDs2c782nPNQCFSsnkEMssj2ies

function GET_CHANNEL_ID($GET_BY_USERNAME) {
    $url = "https://www.googleapis.com/youtube/v3/channels?part=id&forUsername=" . $GET_BY_USERNAME . "&key=" . YOUTUBE_API_KEY;
    $JSON_RESPONSE = GET_JSON_API_DATA($url);
    return $JSON_RESPONSE->items[0]->id;
}
/* GET CHANNEL OWNER PICTURE
https://www.googleapis.com/youtube/v3/channels?part=snippet&id=UCHfi2AdmAeHdRlOIXbf_KZA&key=AIzaSyC5Ug8edDs2c782nPNQCFSsnkEMssj2ies
*/
function GET_CHANNEL_DETAILS($GET_BY_CHANNEL_ID) {
    $url = "https://www.googleapis.com/youtube/v3/channels?part=snippet&id=" . $GET_BY_CHANNEL_ID . "&key=" . YOUTUBE_API_KEY;
    $JSON_RESPONSE = GET_JSON_API_DATA($url);
    return $JSON_RESPONSE->items[0]->snippet;
}

// https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id=UCHfi2AdmAeHdRlOIXbf_KZA&key=AIzaSyC5Ug8edDs2c782nPNQCFSsnkEMssj2ies

function GET_UPLOADS_ID($GET_BY_CHANNEL_ID) {
    $url = "https://www.googleapis.com/youtube/v3/channels?part=contentDetails&id=" . $GET_BY_CHANNEL_ID . "&key=" . YOUTUBE_API_KEY;
    $JSON_RESPONSE = GET_JSON_API_DATA($url);
    return $JSON_RESPONSE->items[0]->contentDetails->relatedPlaylists->uploads;
}

// https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&amp;maxResults=5&amp;playlistId=UUHfi2AdmAeHdRlOIXbf_KZA&amp;key=AIzaSyC5Ug8edDs2c782nPNQCFSsnkEMssj2ies

function GET_VIDEO_LIST($playlistId, $MAX_RESULTS) {
    $url = "https://www.googleapis.com/youtube/v3/playlistItems?part=snippet&maxResults=" . $MAX_RESULTS . "&playlistId=" . $playlistId . "&key=" . YOUTUBE_API_KEY;
    $JSON_RESPONSE = GET_JSON_API_DATA($url);
    return $JSON_RESPONSE->items;
}
// JSON RESPONSE
function PARSE_VIDEO_LIST($VIDEO_LIST) {
    $VIDEO_LIST_PARSED = array();

    foreach ($VIDEO_LIST as $VIDEO_ITEMS) {
        $GET_JSON_VIDEO_DETAILS = $VIDEO_ITEMS->snippet;

        $VIDEO_ITEMS = new VIDEO_ITEM_OBJECTS(
        $GET_JSON_VIDEO_DETAILS->publishedAt,
        $GET_JSON_VIDEO_DETAILS->title,
        $GET_JSON_VIDEO_DETAILS->description,
        $GET_JSON_VIDEO_DETAILS->thumbnails->high->url, // UPLOADER PICTURE
        $GET_JSON_VIDEO_DETAILS->resourceId->videoId
    );
        array_push($VIDEO_LIST_PARSED, $VIDEO_ITEMS);
    }

    return $VIDEO_LIST_PARSED;
}

function YOUTUBE_CHANNEL_URL($GET_BY_CHANNEL_ID) {
    return "https://youtube.com/channel/" . $GET_BY_CHANNEL_ID;
}

function GENERATE_RSS($GET_BY_CHANNEL_ID, $GET_CHANNEL_DETAIL, &$VIDEOS) {
    $FEED_GENERATOR = new RSS_FEED_GENERATOR(
        $GET_CHANNEL_DETAIL->title,
        YOUTUBE_CHANNEL_URL($GET_BY_CHANNEL_ID),
        $GET_CHANNEL_DETAIL->description,
        "en",
        $VIDEOS
    );

    return $FEED_GENERATOR->GENERATE_RSS_FEED();
}

// GET FUNCTION
function main() {
    $MAX_RESULTS = 10; // MAXIMUM 50
    $GET_BY_CHANNEL_ID = NULL;

    if (isset($_GET['username'])) {
        $GET_BY_USERNAME   = htmlspecialchars($_GET['username']);
        $GET_BY_CHANNEL_ID = GET_CHANNEL_ID($GET_BY_USERNAME);
    } elseif (isset($_GET['channel_id'])) {
        $GET_BY_CHANNEL_ID = htmlspecialchars($_GET['channel_id']);
    } else {
        echo "Invalid Arguments, Give Either Username or Channel ID";
        return;
    }

    $GET_CHANNEL_DETAIL  = GET_CHANNEL_DETAILS($GET_BY_CHANNEL_ID);
    $UPLOADS_PLAYLIST_ID = GET_UPLOADS_ID($GET_BY_CHANNEL_ID);

    if (is_null($GET_CHANNEL_DETAIL) || is_null($UPLOADS_PLAYLIST_ID)) {
        echo("Invalid Username or Channel ID");
		header( "refresh:1;url=./" );
        return;
    }

    $VIDEO_LIST  = GET_VIDEO_LIST($UPLOADS_PLAYLIST_ID, $MAX_RESULTS);
    $VIDEOS      = PARSE_VIDEO_LIST($VIDEO_LIST);
    $PRINT_ITEMS = GENERATE_RSS($GET_BY_CHANNEL_ID, $GET_CHANNEL_DETAIL, $VIDEOS);

    echo $PRINT_ITEMS;
}

main();

?>
