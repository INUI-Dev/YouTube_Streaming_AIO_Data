<?php

/*
 Generator @ Kodi dot AL Dev Tools
 Code For PHP 5/7
*/

date_default_timezone_set("Europe/Tirane");

interface GET_RSS_FEED_ITEMS {
    public function GET_FEED_ITEM();
}

class FEED_ITEMS {
    private $title;
    private $link;
    private $pubDate;
    private $description;
    private $thumbnail_url;

    public function __construct(
        $title,
        $link,
        $pubDate,
        $description,
        $thumbnail_url
    )

	{
        $this->title = stripslashes(trim($title)); // IGNORE EMOJI ERRORS
        $this->link = $link;
        $this->pubDate = $pubDate;
        $this->description = htmlentities($description);
		$this->thumbnail_url = $thumbnail_url;
    }

    public function Pub_Date_Format() {
        return date_format($this->pubDate, 'c');
    }

    // GENERATE PLAYER ITEMS
    public function GENERATE_RSS_PLAYLIST()
	{
   // REPLACE
	$YOUTUBE_ID = str_replace(
    array("https://youtube.com/watch?v="),
    array(""),
    $this->link
);

///////////////////////////////////////////////////////////
// DATA - VITI - ORA
$zone = "Europe/Tirane";
$data1 = date("l d/m/Y - H:i:s");
$data2 = date("l, d F Y - H:i:s");
$data3 = date("d F Y");
$viti = date("Y");
///////////////////////////////////////////////////////////

   //$Youtube_Plugin = "plugin://plugin.video.youtube?action=play_video&videoid="; // KJO ESHTE PER LIVE STREAM
    $Youtube_Plugin = "plugin://plugin.video.youtube/play/?video_id=";
    $ITEMS_PLAYLIST_DATA = "<item>\n";
    $ITEMS_PLAYLIST_DATA .= "<title>[COLOR lime][B]" . $this->title . "[/COLOR][/B]</title>\n";
	$ITEMS_PLAYLIST_DATA .= "<thumbnail>" . $this->thumbnail_url . "</thumbnail>\n";
    $ITEMS_PLAYLIST_DATA .= "<fanart>" . $this->thumbnail_url . "</fanart>\n";
    $ITEMS_PLAYLIST_DATA .= "<link>" .$Youtube_Plugin. $YOUTUBE_ID . "</link>\n";
    $ITEMS_PLAYLIST_DATA .= "<Direct_Link>" . $this->link . "</Direct_Link>\n";
    $ITEMS_PLAYLIST_DATA .= "<tube>" . $YOUTUBE_ID . "</tube>\n";
	$ITEMS_PLAYLIST_DATA .= "<connection>keepalive</connection>\n";
    $ITEMS_PLAYLIST_DATA .= "<pubDate>" . $this->Pub_Date_Format() . "</pubDate>\n";
    //$ITEMS_PLAYLIST_DATA .= "<description>" . $this->description . "</description>\n";
	$ITEMS_PLAYLIST_DATA .= "<date>[COLOR lime][B]" . $data2 . "[/B][/COLOR]</date>\n";
    $ITEMS_PLAYLIST_DATA .= "<genre>[COLOR lime][B][I]Albdroid[/I][/B][/COLOR][COLOR lime] [B][I][COLOR red]([/COLOR]" . $this->title . "[COLOR red])[/COLOR] [/I][/B][/COLOR]</genre>\n";
	$ITEMS_PLAYLIST_DATA .= "<info>[COLOR lime][B]Website:[/B][/COLOR] [COLOR red][B]([/B][/COLOR][COLOR lime][B]Albdroid.AL[/B][/COLOR] [COLOR red][B]&amp;[/B][/COLOR] [COLOR lime][B]Kodi.AL[/B][/COLOR][COLOR red][B])[/B][/COLOR]</info>\n";
    $ITEMS_PLAYLIST_DATA .= "</item>\n\n";
    return $ITEMS_PLAYLIST_DATA;
    }
}

// OWNER DETAILS AT MAIN
class RSS_FEED_GENERATOR {
    private $title;
    private $owner_link;
    private $uploader_description;
    private $language_code;
    private $owner_item_list;

    public function __construct(
    $title,
    $owner_link,
    $uploader_description,
    $language_code,
    $owner_item_list // MUST BE AN ARRAY OF OBJECTS WHICH IMPLEMENT GET_RSS_FEED_ITEMS
    )

	{
    $this->title = htmlentities($title);
    $this->owner_link = $owner_link;
    $this->uploader_description = htmlentities($uploader_description);
    $this->language_code = htmlentities($language_code);
    $this->owner_item_list = $owner_item_list;
    }

    // GENERATE OWNER DETAILS
    private function STRUKTURA_NE_FILLIM_UPLOADER_DETAILS()
	{
	$Stream_Provider =  $this->title . " Videos ";
	//$Stream_Provider = "YouTube Playlist Generator BY ID";
	$Stream_Type = "For KODI";
	$albdroidlogo = "https://png.kodi.al/tv/albdroid/";
	
///////////////////////////////////////////////////////////
// DATA - VITI - ORA
$data1 = date("l d/m/Y - H:i:s");
$data2 = date("l, d F Y - H:i:s");
$data3 = date("d F Y");
$viti = date("Y");
///////////////////////////////////////////////////////////
	
//-----------------------------------------------------------------------------------
    $header = "<?xml version=\"1.0\" encoding=\"UTF-8\" standalone=\"yes\"?>\n";
    $header .= "<channel> <!-- {$Stream_Provider} -->\n";
    $header .= "<name>[COLOR lime][B]{$Stream_Provider}{$Stream_Type} at Albdroid TV[/B][/COLOR]</name>\n";
    $header .= "<thumbnail>https://png.kodi.al/tv/albdroid/black.png</thumbnail>\n";
    $header .= "<fanart>https://png.kodi.al/tv/albdroid/black.png</fanart>\n";
    $header .= "<items_info> <!-- THIS IS OPTIONAL -->\n";
    $header .= "<title>[COLOR lime][B][I]Albdroid[/I][/B][/COLOR][COLOR lime] [B][I][COLOR red]([/COLOR]{$Stream_Provider}{$Stream_Type}[COLOR red])[/I][/B][/COLOR]</title>\n";
    $header .= "<genre>[COLOR lime][B][I]Albdroid[/I][/B][/COLOR][COLOR lime] [B][I][COLOR red]([/COLOR]{$Stream_Provider}{$Stream_Type}[COLOR red])[/I][/B][/COLOR]</genre>\n";
    $header .= "<description>[COLOR blue][B]Author:[/COLOR] [COLOR lime][B]Olsion Bakiaj[/B][/COLOR][COLOR red] &amp;[/COLOR][COLOR lime][B] Endrit Pano[/B][/COLOR]</description>\n";
    $header .= "<thumbnail>https://png.kodi.al/tv/albdroid/black.png</thumbnail>\n";
    $header .= "<fanart>https://png.kodi.al/tv/albdroid/black.png</fanart>\n";
    $header .= "<date>[COLOR lime][B]{$data3}[/B][/COLOR]</date>\n";
    $header .= "<credits>[COLOR lime]TRC4[/B][/COLOR]</credits>\n";
    $header .= "<year>[COLOR lime][B]{$viti}[/B][/COLOR]</year>\n";
    $header .= "<language>" . $this->language_code . "</language>\n";
    $header .= "<channel_description>" . $this->uploader_description . "</channel_description>\n";
    $header .= "<channel_owner>" . $this->title . "</channel_owner>\n";
    $header .= "<owner_link>" . $this->owner_link . "</owner_link>\n";
    $header .= "</items_info>\n\n";

    return $header;
    }
    // GENERATE ATTRIBUTES AT END
    private function STRUKTURA_FUND_CLOSE_ITEMS()
	{
	//$SetViewMode = "504";
    $footer = "<SetViewMode>504</SetViewMode>\n\n";
    $footer .= "</channel>";
    return $footer;
    }
    // GENERATE LIST
    public function GENERATE_RSS_FEED() {
    $FEED_ITEMS_LIST = $this->STRUKTURA_NE_FILLIM_UPLOADER_DETAILS();

    foreach ($this->owner_item_list as $item) {
        $feedItem = $item->GET_FEED_ITEM();
        $FEED_ITEMS_LIST .= $feedItem->GENERATE_RSS_PLAYLIST();
    }

    $FEED_ITEMS_LIST .= $this->STRUKTURA_FUND_CLOSE_ITEMS();
    return $FEED_ITEMS_LIST;
    }
}

?>
