<?php
/*
 Generator @ Kodi dot AL Dev Tools
 Code For PHP 5/7
*/
?>

<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="utf-8" />
<title>YouTube Playlist Generator</title>
<link rel="shortcut icon" href="favicon.ico"/>
<link rel="shortcut icon" href="favicon.ico" type="image/x-icon" />
<link rel="icon" href="favicon.ico"/>
<meta http-equiv="cache-control" content="no-store">
<meta name="viewport" content="width=device-width, initial-scale=1.0" />
<meta name="description" content="YouTube Playlist Generator" />
<meta name="author" content="Olsion Bakiaj" />
<meta property="og:site_name" content="YouTube Playlist Generator">
<meta property="og:locale" content="en_US">
<meta name="msapplication-TileColor" content="#0F0">
<meta name="theme-color" content="#0F0">
<meta name="msapplication-navbutton-color" content="#0F0">
<meta name="apple-mobile-web-app-capable" content="yes">
<meta name="apple-mobile-web-app-status-bar-style" content="#0F0">
<link rel="google-play-app" content="app-id=player.kodi.al">
<link href="./assets/css/bootstrap.css" rel="stylesheet" />
<link href="./assets/css/bubble.css" rel="stylesheet" />
<link href="./assets/css/hover.css" rel="stylesheet" />
<link href="./assets/css/styles.css" rel="stylesheet" />
<link href="./assets/css/blink.css" rel="stylesheet" />
<style type="text/css">
body,td,th {
	color: #0F0;
}
body {
	background-color: #000000;
}
a:link {
	color: #00FF00;
}
a:visited {
	color: #00FF00;
}
a:hover {
	color: #00FF00;
}
a:active {
	color: #00FF00;
}

</style>
<?php
// include 'crypt.php';
?>
</head>
<body>
<div class="container">
<center>
<header class="page-header">
<img src="assets/images/youtube_lime.png" alt="YouTube RSS">
<!-- HAPUR -->
<h4>YouTube Playlist Generator</h4>
<!-- HAPUR -->
</header>
</center>
<!-- EXTRA --/>
<div class="blank_div_5px">
</div>
<!-- EXTRA -->

<div class="row">
<div class="col-md-12">
<!-- HAPUR --/>
<div class="readme">
<p>Compile YouTube RSS By Username</p>
<p>Compile YouTube RSS By Channel ID</p>
</div>
<!-- HAPUR -->
<center>
<textarea id="editor" style="margin: 0px 0px 10px; width: 429px; height: 21px;" readonly>YouTube Playlist Generator For Kodi by Username or by Channel ID</textarea>
</center>
<br>
<div id="title_bar" style="background-color: #000; border: 1px dotted lime; color: #0F0;">
<br>
<!-- EXTRA --/>
<div id="emri_programit" style="background-color: #000; color: #0F0;">YouTube RSS Generator</div>
<!-- EXTRA -->
<div class="controls">
<form action="generate.php">
<!----/>
<label>
<br>
<b>User Name:</b>
</label>
<!---->
<b>User Name:</b> <input class="textbox" type="text" name="username" required placeholder="TRC4Deejay">
<span>
<!-- --/>
<input type="submit" value="Generate">
<-- -->
<button type="submit" class="btn btn-success">Generate</button>
</form>
<form action="generate.php">

<b>Channel ID:</b> <input class="textbox" type="text" name="channel_id" required placeholder="UCHfi2AdmAeHdRlOIXbf_KZA">
<!-- --/>
<input type="submit" value="Generate">
<!-- -->
<button type="submit" class="btn btn-success">Generate</button>
</form>

<script src="assets/js/editor.js"></script>

</div>
</div>
</div>
</div>
<footer class="footer">
&copy; <?php echo date("Y") ?>  <strong>TRC4</strong> <a href="http://kodi.al" target="_blank"><strong>kodi.al</strong></a>
</footer>
</div>
</body>
</html>