<?php

/*
 Generator @ Kodi dot AL Dev Tools
 Code For PHP 5/7
*/

include_once 'rss_generator.php';

class VIDEO_ITEM_OBJECTS implements GET_RSS_FEED_ITEMS {
    private $published;
    private $title;
    private $description;
    private $thumbnail;
    private $videoId;

    public function __construct(
        $published,
        $title,
        $description,
        $thumbnail,
        $videoId
    )

	{
        $this->published = new DateTime($published);
        $this->title = $title;
        $this->description = $description;
        $this->thumbnail = $thumbnail;
        $this->videoId = $videoId;
    }

    public function getUrl() {
        return "https://youtube.com/watch?v=" . $this->videoId;
		// return "" . $this->videoId; WITHOUT LINK
    }

    public function GET_FEED_ITEM() {
        return new FEED_ITEMS(
            $this->title,
            $this->getUrl(),
            $this->published,
			//$this->videoId,//
            $this->description,
            $this->thumbnail
        );
    }
}

?>
